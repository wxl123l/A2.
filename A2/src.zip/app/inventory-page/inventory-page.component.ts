import { Component } from '@angular/core';

interface InventoryItem {
  name: string;
  description: string;
  quantity: number;
  price: number;
}

@Component({
  selector: 'app-inventory-page',
  templateUrl: './inventory-page.component.html',
  styleUrls: ['./inventory-page.component.css']
})
export class InventoryPageComponent {
  items: InventoryItem[] = [];
  currentItem: InventoryItem = { name: '', description: '', quantity: 0, price: 0 };
  editing: boolean = false;
  message: string = '';
  messageType: 'success' | 'error' = 'success';

  addItem() {
    if (this.validateItem()) {
      const existingItem = this.items.find(item => item.name === this.currentItem.name);
      if (existingItem) {
        this.showMessage('Item with this name already exists', 'error');
        return;
      }
      this.items.push({ ...this.currentItem });
      this.resetForm();
      this.showMessage('Item added successfully', 'success');
    }
  }

  editItem(item: InventoryItem) {
    this.currentItem = { ...item };
    this.editing = true;
  }

  updateItem() {
    if (this.validateItem()) {
      const index = this.items.findIndex(item => item.name === this.currentItem.name);
      if (index !== -1) {
        this.items[index] = { ...this.currentItem };
        this.resetForm();
        this.showMessage('Item updated successfully', 'success');
      }
    }
  }

  deleteItem(name: string) {
    if (confirm(`Are you sure you want to delete item: ${name}?`)) {
      this.items = this.items.filter(item => item.name !== name);
      this.showMessage('Item deleted successfully', 'success');
    }
  }

  resetForm() {
    this.currentItem = { name: '', description: '', quantity: 0, price: 0 };
    this.editing = false;
  }

  validateItem(): boolean {
    if (!this.currentItem.name) {
      this.showMessage('Item name is required', 'error');
      return false;
    }
    if (this.currentItem.quantity < 0) {
      this.showMessage('Quantity cannot be negative', 'error');
      return false;
    }
    if (this.currentItem.price < 0) {
      this.showMessage('Price cannot be negative', 'error');
      return false;
    }
    return true;
  }

  showMessage(message: string, type: 'success' | 'error') {
    this.message = message;
    this.messageType = type;
    setTimeout(() => {
      this.message = '';
    }, 3000);
  }
}