import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';

import { AppComponent } from './app.component';
import { HomePageComponent } from './home-page/home-page.component';
import { InventoryPageComponent } from './inventory-page/inventory-page.component';
import { SearchPageComponent } from './search-page/search-page.component';
import { PrivacyPageComponent } from './privacy-page/privacy-page.component';
import { HelpPageComponent } from './help-page/help-page.component';

const routes: Routes = [
  { path: '', component: HomePageComponent },
  { path: 'inventory', component: InventoryPageComponent },
  { path: 'search', component: SearchPageComponent },
  { path: 'privacy', component: PrivacyPageComponent },
  { path: 'help', component: HelpPageComponent }
];

@NgModule({
  declarations: [
    AppComponent,
    HomePageComponent,
    InventoryPageComponent,
    SearchPageComponent,
    PrivacyPageComponent,
    HelpPageComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    RouterModule.forRoot(routes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }