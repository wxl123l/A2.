import { Component } from '@angular/core';

interface FAQ {
  question: string;
  answer: string;
}

@Component({
  selector: 'app-help-page',
  templateUrl: './help-page.component.html',
  styleUrls: ['./help-page.component.css']
})
export class HelpPageComponent {
  faqs: FAQ[] = [
    {
      question: 'How do I add a new inventory item?',
      answer: 'Navigate to the Inventory page, fill out the form with the item details, and click "Add Item".'
    },
    {
      question: 'How do I edit an existing item?',
      answer: 'On the Inventory page, find the item you want to edit and click the "Edit" button. Update the details and click "Update Item".'
    },
    {
      question: 'How do I delete an item?',
      answer: 'On the Inventory page, find the item you want to delete and click the "Delete" button. Confirm the deletion in the prompt.'
    },
    {
      question: 'How do I search for items?',
      answer: 'Navigate to the Search page, enter your search term in the search box, and click "Search".'
    },
    {
      question: 'What are popular items?',
      answer: 'Popular items are items with a quantity greater than 10. They are displayed on the Search page.'
    }
  ];

  troubleshootingSteps = [
    'Check that all required fields are filled out correctly.',
    'Ensure numeric fields only contain numbers.',
    'Make sure item names are unique.',
    'Clear your browser cache if the application is not responding.',
    'Refresh the page to reset the application state.'
  ];
}