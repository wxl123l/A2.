import { Component } from '@angular/core';

interface InventoryItem {
  name: string;
  description: string;
  quantity: number;
  price: number;
}

@Component({
  selector: 'app-search-page',
  templateUrl: './search-page.component.html',
  styleUrls: ['./search-page.component.css']
})
export class SearchPageComponent {
  items: InventoryItem[] = [
    { name: 'Laptop', description: 'Dell XPS 13', quantity: 10, price: 999.99 },
    { name: 'Phone', description: 'iPhone 14', quantity: 15, price: 799.99 },
    { name: 'Tablet', description: 'iPad Pro', quantity: 8, price: 899.99 },
    { name: 'Monitor', description: '27 inch 4K', quantity: 5, price: 399.99 },
    { name: 'Keyboard', description: 'Mechanical', quantity: 20, price: 129.99 }
  ];
  searchTerm: string = '';
  filteredItems: InventoryItem[] = [];

  constructor() {
    this.filteredItems = this.items;
  }

  searchItems() {
    if (!this.searchTerm) {
      this.filteredItems = this.items;
      return;
    }

    const term = this.searchTerm.toLowerCase();
    this.filteredItems = this.items.filter(item => 
      item.name.toLowerCase().includes(term) ||
      item.description.toLowerCase().includes(term)
    );
  }

  get popularItems() {
    return this.items.filter(item => item.quantity > 10);
  }
}